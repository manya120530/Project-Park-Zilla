package project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class BookingPage {

    private JFrame frame;
    private JTextField slotIdField;
    private JTextField vehicleTypeField;
    private JTextField bookingDateTimeField;
    private JTextField durationField;
    private Connection connection;
    
    private int getLoggedInCustomerId(String username, String password) throws SQLException {
        int customerId = -1; // Default value if customer ID is not found

        // Prepare SQL statement to retrieve customer ID based on username and password
        String query = "SELECT customer_id FROM login WHERE username = ? AND password = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, username);
            statement.setString(2, password);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    customerId = resultSet.getInt("customer_id");
                }
            }
        }
        return customerId;
    }
    
    public BookingPage() {
        initialize();
        connectToDatabase(); // Establish database connection
    }

    private void initialize() {
        frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setMinimumSize(new Dimension(1000, 526));
        frame.setTitle("Booking Page");

        // Define custom color
        Color customTextColor = new Color(133, 232, 235);

        // Create a JLabel with the background image
        JLabel backgroundLabel = new JLabel(new ImageIcon("C:\\\\Users\\\\ANEESH MINJ\\\\Downloads\\\\PARK-ZILLA (2).png"));
        backgroundLabel.setLayout(new GridBagLayout());
        frame.setContentPane(backgroundLabel);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10); // Padding

        JPanel panel = new JPanel();
        panel.setOpaque(false); // Make the panel transparent
        panel.setLayout(new GridBagLayout());
        backgroundLabel.add(panel, gbc);

        JLabel slotIdLabel = new JLabel("Slot ID:");
        slotIdLabel.setForeground(customTextColor); // Set custom text color
        slotIdField = new JTextField(20);
        slotIdField.setForeground(customTextColor); // Set custom text color
        JLabel vehicleTypeLabel = new JLabel("Vehicle Type:");
        vehicleTypeLabel.setForeground(customTextColor); // Set custom text color
        vehicleTypeField = new JTextField(20);
        vehicleTypeField.setForeground(customTextColor); // Set custom text color
        JLabel bookingDateTimeLabel = new JLabel("Booking Date & Time:");
        bookingDateTimeLabel.setForeground(customTextColor); // Set custom text color
        bookingDateTimeField = new JTextField(20);
        bookingDateTimeField.setForeground(customTextColor); // Set custom text color
        JLabel durationLabel = new JLabel("Duration:");
        durationLabel.setForeground(customTextColor); // Set custom text color
        durationField = new JTextField(20);
        durationField.setForeground(customTextColor); // Set custom text color

        JButton bookButton = new JButton("Book");
        bookButton.setPreferredSize(new Dimension(150, 40)); // Set custom button size
        bookButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                bookSlot();
            }
        });

        JButton logoutButton = new JButton("Logout");
        logoutButton.setPreferredSize(new Dimension(150, 40)); // Set custom button size
        logoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                logout();
            }
        });

        // Center-align text on labels
        slotIdLabel.setHorizontalAlignment(SwingConstants.CENTER);
        vehicleTypeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        bookingDateTimeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        durationLabel.setHorizontalAlignment(SwingConstants.CENTER);

        // Set custom font size and color for labels
        Font customFont = new Font("Arial", Font.BOLD, 16);
        slotIdLabel.setFont(customFont);
        vehicleTypeLabel.setFont(customFont);
        bookingDateTimeLabel.setFont(customFont);
        durationLabel.setFont(customFont);

        // Add components to the panel
        gbc.gridy++;
        panel.add(slotIdLabel, gbc);
        gbc.gridy++;
        panel.add(slotIdField, gbc);
        gbc.gridy++;
        panel.add(vehicleTypeLabel, gbc);
        gbc.gridy++;
        panel.add(vehicleTypeField, gbc);
        gbc.gridy++;
        panel.add(bookingDateTimeLabel, gbc);
        gbc.gridy++;
        panel.add(bookingDateTimeField, gbc);
        gbc.gridy++;
        panel.add(durationLabel, gbc);
        gbc.gridy++;
        panel.add(durationField, gbc);
        gbc.gridy++;
        panel.add(logoutButton, gbc); // Added logout button
        gbc.gridy++;
        panel.add(bookButton, gbc);

        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void bookSlot() {
        try {
            // Get the username and password from your login page
            String username = ""; // Get the username from your login page
            String password = ""; // Get the password from your login page
            
            int customerId = getLoggedInCustomerId(username, password); // Replace username and password with actual credentials

            int slotId = Integer.parseInt(slotIdField.getText());
            String vehicleType = vehicleTypeField.getText();
            String bookingDateTime = bookingDateTimeField.getText();
            int duration = Integer.parseInt(durationField.getText());

            // Check if slot is available

            // Perform booking
            PreparedStatement statement = connection.prepareStatement(
                    "INSERT INTO booked_slots (customer_id, slot_number, booking_time, duration, vehicle_type) " +
                            "VALUES (?, ?, ?, ?, ?)");
            statement.setInt(1, customerId); // Use the retrieved customer ID
            statement.setInt(2, slotId);
            statement.setString(3, bookingDateTime);
            statement.setInt(4, duration);
            statement.setString(5, vehicleType);
            int rowsAffected = statement.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(frame, "Slot booked successfully!");
            } else {
                JOptionPane.showMessageDialog(frame, "Failed to book the slot.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException | SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Invalid input or database error.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }



    private void connectToDatabase() {
        String url = "jdbc:mysql://localhost:3307/parking_management_system";
        String username = "root"; // Change this
        String password = "root"; // Change this

        try {
            connection = DriverManager.getConnection(url, username, password);
            System.out.println("Connected to the database.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void logout() {
        frame.dispose(); // Close the booking page
        new LogoutPage(); // Open the logout page
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    BookingPage window = new BookingPage();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
